# -*- coding: utf-8 -*-

from . import training_session
from . import hr_employee_inherit
