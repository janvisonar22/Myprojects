# -*- coding: utf-8 -*-

from . import student_details_fill
from . import student_list_controller
