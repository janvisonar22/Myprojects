# -*- coding: utf-8 -*-

from . import inventory_status_report
