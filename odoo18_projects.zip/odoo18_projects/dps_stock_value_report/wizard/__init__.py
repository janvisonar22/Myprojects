# -*- coding: utf-8 -*-
from . import stock_inventory_report_wizard
