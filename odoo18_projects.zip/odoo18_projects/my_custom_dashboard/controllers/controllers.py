# from odoo import http

# class StudentList(http.Controller):
# 	@http.route('/dashboard',auth='public')
# 	def mypage(self,**kwargs):
# 		return "Hello World"