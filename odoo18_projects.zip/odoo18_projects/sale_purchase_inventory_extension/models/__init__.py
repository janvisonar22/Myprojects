# -*- coding: utf-8 -*-

from . import sale_order_inherit
from . import purchase_order_inherit
