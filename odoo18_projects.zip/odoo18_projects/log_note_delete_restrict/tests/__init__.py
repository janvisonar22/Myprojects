from . import test_log_note_delete_restrict
