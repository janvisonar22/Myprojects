/** @odoo-module **/ 
// Your module name: text_to_speech_custom

import { FormController } from "@web/views/form/form_controller";
import { patch } from "@web/core/utils/patch";

// FormController.prototype को सीधे patch करना Odoo 16+ में गलत है।
// हमें patch function को केवल दो arguments के साथ call करना चाहिए।
// हालांकि, Odoo UI elements को patch करने के लिए Component layer को use करना preferred है।
// चूंकि FormController एक class है, हम इसे functional component की तरह patch कर सकते हैं।

// Patch the FormController.prototype class
patch(FormController.prototype, {
    /**
     * Override the default method to handle the 'action_speak' button click.
     */
    async onButtonClick(params) {
        // Check if the button is 'action_speak' of type 'object'
        if (params.clickParams.name === "action_speak" && params.clickParams.type === "object") {
            
            // Get the current record data from the model root
            // Note: In Odoo 16+, the model structure changes, but this is the functional equivalent.
            const record = this.model.root;
            console.log("record===>>><<<>>",record)
            const text = record.data.name;
            print("\n\ntexttext===>>",text)
            if (!text) {
                alert("Please enter some text to speak!");
                return;
            }

            // Web Speech API implementation
            let speech = new SpeechSynthesisUtterance(text);
            console.log("\n\nspeech===>",speech)
            speech.lang = "en-US"; // English (or 'hi-IN' for Hindi if supported by browser)
            speech.rate = 1;
            speech.pitch = 1;
            
            // Cancel any previous speech before starting a new one
            window.speechSynthesis.cancel();
            window.speechSynthesis.speak(speech);

            // Prevent Odoo from calling the dummy Python method (important for custom JS logic)
            return; 
        }

        // Call the original method for all other buttons
        return this._super.apply(this, arguments);
    },
});