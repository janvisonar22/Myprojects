# -*- coding: utf-8 -*-

from . import text_to_speech
