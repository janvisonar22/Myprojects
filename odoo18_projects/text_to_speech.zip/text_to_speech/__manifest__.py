{
    'name': 'Text To Speech',
    'version': '18.0',
    'depends': ['web'],
    'data': [
        'security/ir.model.access.csv',   # <-- आपके CSV का path

        'views/text_to_speech.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'text_to_speech/static/src/js/text_to_speech.js',
        ],
    },

    'installable': True,
    'application': False,
    'auto_install': False,

}
