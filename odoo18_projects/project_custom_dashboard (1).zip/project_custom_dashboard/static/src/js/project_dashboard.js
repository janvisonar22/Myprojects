/** @odoo-module **/
import { registry } from "@web/core/registry";
import { Component } from "@odoo/owl";
const actionRegistry = registry.category("actions");
class ProjectDashboard extends Component {}
ProjectDashboard.template = "project_custom_dashboard.ProjectDashboard";
actionRegistry.add("project_dashboard_tag", ProjectDashboard);
