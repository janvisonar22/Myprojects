from odoo import fields, models, api


class Project(models.Model):
    _inherit = "project.project"

    @api.model
    def get_project_custom_dashboard_data(self):
        total_project = 0.0
        project_ids = self.env['project.project'].search([])
        total_project = project_ids and len(project_ids.ids) or 0.0
        return {'total_project': total_project}