from odoo import http
from odoo.http import request

class ProjectDashboardController(http.Controller):

	@http.route('/project_dashboard/data', auth='user', type='json')
	def get_dashboard_data(self):
		data = request.env['project.dashboard'].sudo().get_dashboard_data()
		return data