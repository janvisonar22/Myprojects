{
    "name": "Project CUSTOM Dashboard",
    "version": "1.0",
    "category": "project",
    "summary": "Dashboard for project KPIs",
    "depends": ["base", "web", "project"],
    "data": [
        "views/project_dashboard_menu.xml",
    ],
    "assets": {
        "web.assets_backend": [
            "project_custom_dashboard/static/src/js/project_dashboard.js",
            "project_custom_dashboard/static/src/xml/project_dashboard_template.xml",
        ],
    },
    "installable": True,
    "application": True,
}
