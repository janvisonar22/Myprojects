/** @odoo-module **/
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
import { Component } from "@odoo/owl";
const actionRegistry = registry.category("actions");
class ProjectDashboard extends Component {

    setup() {
        super.setup();
        this.orm = useService('orm');
        this._fetch_data();
    }
    async _fetch_data(){
         let result = await this.orm.call("project.project", "get_project_custom_dashboard_data", [], {});
         document.getElementById('total_project').innerHTML = `<span>${result.total_project}</span>`;
    }
}
ProjectDashboard.template = "project_custom_dashboard.ProjectDashboard";
actionRegistry.add("project_dashboard_tag", ProjectDashboard);
