# -*- coding: utf-8 -*-
from odoo import models
import io
import xlsxwriter

class StockQuantXlsxReport(models.AbstractModel):
	_name = "report.my_custom_inventory.report_stock_quant_xlsx"
	_inherit = "report.report_xlsx.abstract"
	_description = "Stock Quant XLSX Report"

	def generate_xlsx_report(self, workbook, data, wizard):
		sheet = workbook.add_worksheet("Stock Quantities")

		header_format = workbook.add_format({
			'bold': True, 'bg_color': '#D3D3D3', 'border': 1
		})

		sheet.write(0, 0, "Product", header_format)
		sheet.write(0, 1, "Location", header_format)
		sheet.write(0, 2, "On Hand Quantity", header_format)

		# Get stock data from wizard
		stock_data = wizard._get_stock_data()

		row = 1
		for line in stock_data:
			sheet.write(row, 0, line['product'])
			sheet.write(row, 1, line['location'])
			sheet.write(row, 2, line['qty'])
			row += 1
