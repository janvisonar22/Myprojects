# -*- coding: utf-8 -*-
from odoo import models, fields, api

class WarehouseLocationWizard(models.TransientModel):
	_name = "warehouse.location.wizard"
	_description = "Warehouse Location Wizard"

	warehouse_id = fields.Many2one(
		"stock.warehouse",
		string="Warehouse",
		required=True
	)

	location_ids = fields.Many2many(
		"stock.location",
		string="Locations"
	)

	# @api.onchange('warehouse_id')
	# def _onchange_warehouse_id(self):
	# 	"""Auto-load all locations of selected warehouse"""
	# 	if self.warehouse_id:
	# 		locations = self.env['stock.location'].search([
	# 			('id', 'child_of', self.warehouse_id.view_location_id.id)
	# 		])
	# 		self.location_ids = [(6, 0, locations.ids)]
	# 	else:
	# 		self.location_ids = [(5, 0, 0)]

	# def _get_stock_data(self):
	# 	self.ensure_one()
	# 	locations = self.env['stock.location'].search([
	# 		('usage', '=', 'internal'),
	# 		('id', 'child_of', self.warehouse_id.view_location_id.id)
	# 	])
	# 	quants = self.env['stock.quant'].search([
	# 		('location_id', 'in', locations.ids)
	# 	])

	# 	data = []
	# 	for quant in quants:
	# 		data.append({
	# 			'product': quant.product_id.display_name,
	# 			'location': quant.location_id.complete_name,
	# 			'qty': quant.quantity,   
	# 		})
	# 	return data



	def action_print_xlsx(self):
		return self.env.ref("my_custom_inventory.action_stock_quant_xlsx").report_action(self)












































# from odoo import models, fields, api

# class MyReportWizard(models.TransientModel):
# 	_name = "my.report.wizard"
# 	_description = "My Report Wizard"

# 	# name = fields.Char(string="Report Name", required=True)
# 	warehouse_id = fields.Many2one(
# 		'stock.warehouse',
# 		string='Warehouse',
# 		required=True
# 	)
# 	location_ids = fields.Many2many('stock.location', string='Locations')
# 	start_date = fields.Date(string="Start Date")
# 	end_date = fields.Date(string="End Date")

# 	html_preview = fields.Html(string="Preview", sanitize=False, readonly=True)
	
# 	def xlsx_report_print_report(self):
# 		return self.env.ref("my_custom_inventory.action_my_stock_xlsx_report").report_action(self)

# 	@api.onchange('warehouse_id')
# 	def onchange_warehouse_id(self):
# 		stock_location_obj = self.env['stock.location']

# 		if self.warehouse_id:
# 			self.location_ids = stock_location_obj.search([
# 				('usage', '=', 'internal'),
# 				('location_id', 'child_of', self.warehouse_id.mapped('view_location_id.id')),
# 			])
# 		else:
# 			self.location_ids = False

# 		return {'domain': {'location_ids': [('id', 'in', self.location_ids.ids)]}}


# 	def _get_stock_movements(self):
# 		"""Fetch stock moves based on filters"""
# 		domain = [
# 			('date', '>=', self.start_date),
# 			('date', '<=', self.end_date),
# 			('state', '=', 'done'),
# 		]
# 		if self.location_ids:
# 			domain += ['|',
# 				('location_id', 'in', self.location_ids.ids),
# 				('location_dest_id', 'in', self.location_ids.ids)
# 			]

# 		stock_moves = self.env['stock.move'].search(domain)
# 		return stock_moves
# 	# @api.depends('warehouse_id')
# 	# def _compute_products(self):
# 	# 	for wizard in self:
# 	# 		if wizard.warehouse_id:
# 	# 			locations = self.env['stock.location'].search([
# 	# 				('usage', '=', 'internal'),
# 	# 				('id', 'child_of', wizard.warehouse_id.mapped('lot_stock_id').ids)
# 	# 			])
# 	# 			products = self.env['stock.quant'].search([
# 	# 				('location_id', 'in', locations.ids)
# 	# 			]).mapped('product_id')
# 	# 			wizard.product_ids = products
# 	# 		else:
# 	# 			wizard.product_ids = self.env['product.product'].browse([])

# 	def action_preview_report(self):
# 		"""Generate preview in HTML"""
# 		stock_moves = self._get_stock_movements()
# 		preview_html = "<h3>Stock Movements Report</h3>"
# 		preview_html += f"<p><b>Date Range:</b> {self.start_date} → {self.end_date}</p>"

# 		product_data = {}
# 		for move in stock_moves:
# 			qty = move.product_uom_qty if move.location_dest_id in self.location_ids else -move.product_uom_qty
# 			product_data.setdefault(move.product_id.name, 0)
# 			product_data[move.product_id.name] += qty

# 		preview_html += "<ul>"
# 		for product, qty in product_data.items():
# 			preview_html += f"<li>{product}: {qty} units</li>"
# 		preview_html += "</ul>"

# 		self.html_preview = preview_html

# 	# def pdf_report_print(self):
# 	# 	"""PDF report action"""
# 	# 	return self.env.ref("my_custom_inventory.action_my_stock_pdf").report_action(self)
# 	product_ids = fields.Many2many(
# 	'product.product',
# 	string='Products',
# 	compute='_compute_products',
# 	store=False
# 	)

# 	def _prepare_report_datas(self):
# 		"""Prepare data for PDF"""
# 		self.ensure_one()

# 		# Warehouse → Internal Locations
# 		locations = self.env['stock.location'].search([
# 			('usage', '=', 'internal'),
# 			('id', 'child_of', self.warehouse_id.view_location_id.id)
# 		])

# 		# Quant se product stock nikaalo
# 		quants = self.env['stock.quant'].search([
# 			('location_id', 'in', locations.ids)
# 		])

# 		product_data = {}
# 		for quant in quants:
# 			product_data.setdefault(quant.product_id, 0.0)
# 			product_data[quant.product_id] += quant.quantity

# 		return {
# 			'start_date': self.start_date,
# 			'end_date': self.end_date,
# 			'warehouse': self.warehouse_id,
# 			'product_data': product_data,  # {product_id : qty}
# 		}

# 	# def pdf_report_print(self):
# 	# 	"""PDF report action"""
# 	# 	data = self._prepare_report_datas()
# 	# 	return self.env.ref("my_custom_inventory.action_my_stock_pdf").report_action(self, data=data)
# 	# def pdf_report_print(self):
# 	# 	report_data = self._prepare_report_datas()
# 	# 	return self.env.ref('my_custom_inventory.action_my_stock_pdf').report_action(
# 	# 		self, data={'report_data': report_data}
# 	# 	)

