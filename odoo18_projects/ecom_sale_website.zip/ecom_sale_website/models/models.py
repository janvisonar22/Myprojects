from odoo import models, fields

class EcomSaleWebsite(models.Model):
	_name = 'ecom.sale.website'
	_description = 'E-Commerce Website Bidding'

	name = fields.Char(string="Product Name")
	customer_id = fields.Many2one('res.partner', string="Customer", required=True)
	customer_phone = fields.Char(related="customer_id.phone", string="Phone", store=True)
	customer_email = fields.Char(related="customer_id.email", string="Email", store=True)

	product_id = fields.Many2one('product.template', string="Product")
	price = fields.Float(string="Product Price")
	suggestion_price = fields.Float(string="Suggestion Price")
	state = fields.Selection([
		('draft', 'Draft'),
		('quotation', 'Quotation'),
		('done', 'Done'),
		('cancel', 'Cancel'),
	], string="State", default='draft', tracking=True)
