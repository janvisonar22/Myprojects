from odoo import http
from odoo.http import request
from odoo.addons.portal.controllers.portal import CustomerPortal

class CustomProductsPortal(CustomerPortal):

	def _prepare_home_portal_values(self, counters):
		values = super()._prepare_home_portal_values(counters)
		# Add product count for portal card
		product_count = request.env['ecom.sale.website'].sudo().search_count([])
		values.update({
			'product_count': product_count
		})
		return values

class ProductsPortal(http.Controller):

	@http.route(['/my/products', '/my/products/page/<int:page>'], type='http', auth='user', website=True)
	def portal_my_products(self, page=1, **kw):
		Product = request.env['ecom.sale.website']
		
		# Pager
		product_count = Product.sudo().search_count([])
		pager = request.website.pager(
			url="/my/products",
			total=product_count,
			page=page,
			step=20
		)

		products = Product.sudo().search([], limit=20, offset=pager['offset'])
		
		return request.render("ecom_sale_website.portal_my_products_template", {
			'products': products,
			'pager': pager,
			'page_name': 'products',
			'default_url': '/my/products',
		})

# from odoo.addons.portal.controllers.portal import CustomerPortal
# from odoo.http import request
# from odoo import http

# class CustomProductsPortal(CustomerPortal):

# 	def _prepare_home_portal_values(self, counters):
# 		values = super()._prepare_home_portal_values(counters)
# 		if 'product_count' in counters:
# 			product_count = request.env['ecom.sale.website'].sudo().search_count([])
# 			values['product_count'] = product_count
# 		return values


# class ProductsPortal(http.Controller):

# 	@http.route(['/my/products'], type='http', auth='user', website=True)
# 	def portal_my_products(self, **kw):
# 		products = request.env['ecom.sale.website'].sudo().search([])
# 		return request.render("ecom_sale_website.portal_my_products_template", {
# 			'products': products,
# 		})