from odoo import http
from odoo.http import request

class BiddingController(http.Controller):

	@http.route(['/bidding/<int:product_id>'], type='http', auth="public", website=True)
	def bidding_page(self, product_id, **kwargs):
		product = request.env['product.template'].sudo().browse(product_id)
		if not product.exists():
			return request.not_found()
		return request.render("ecom_sale_website.bidding_template", {'product': product})

	@http.route(['/bidding/save/<int:product_id>'], type='http', auth="public", website=True, csrf=True, methods=['POST'])
	def save_bidding(self, product_id, **post):
		product = request.env['product.template'].sudo().browse(product_id)
		if not product.exists():
			return request.not_found()

		customer_name = post.get('customer_name')
		customer_phone = post.get('customer_phone')
		customer_email = post.get('customer_email')
		suggestion_price = post.get('suggestion_price')

		# Partner check by email
		partner = request.env['res.partner'].sudo().search([('email', '=', customer_email)], limit=1)
		if not partner:
			# Create new partner
			partner = request.env['res.partner'].sudo().create({
				'name': customer_name,
				'phone': customer_phone,
				'email': customer_email,
			})
		else:
			# Update existing partner details
			partner.sudo().write({
				'name': customer_name,
				'phone': customer_phone,
			})

		# Create bidding record
		request.env['ecom.sale.website'].sudo().create({
			'name': product.name,
			'product_id': product.id,
			'price': product.list_price,
			'suggestion_price': suggestion_price,
			'customer_id': partner.id,
		})

		return request.render('ecom_sale_website.bidding_confirmation', {
			'product': product,
			'suggestion_price': suggestion_price,
			'customer': partner,
		})
