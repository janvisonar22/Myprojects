{
    'name': "ecom_sale_website",
    'summary': "Custom E-Commerce Bidding Button",
    'description': "Add Bidding button next to Add to Cart button on product page.",
    'author': "My Company",
    'website': "https://www.yourcompany.com",
    'category': 'Website/Website',
    'version': '0.1',
    'depends': ['website_sale','portal'],
    'data': [
        'security/ir.model.access.csv',
        'views/main_page.xml',
        'views/snippets/bidding_portal_front_view.xml',
        'views/snippets/templates.xml',


        'views/menu.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,

    'assets': {
    'web.assets_frontend': [
        'ecom_sale_website/static/src/scss/portal_products.scss',
    ],
},

}
