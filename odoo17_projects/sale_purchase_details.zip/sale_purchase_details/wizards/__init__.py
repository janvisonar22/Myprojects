from . import sale_purchase_details
