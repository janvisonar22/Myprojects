/** @odoo-module */
import { Component } from "@odoo/owl";

class PurchaseCard extends Component {}

PurchaseCard.template = "purchase_dashboard.PurchaseCard";

export default PurchaseCard;
// /* @odoo-module */
// // import {registry} from '@web/core/registry';
// import { Component } from "@odoo/owl";
// export class PurchaseCard extends Component{}
// PurchaseCard.template = 'purchase_dashboard.PurchaseCard';
// // PurchaseCard.props=['purchase_order_count','rfq','rfq_sent','to_approve','purchase','done','cancel'];
