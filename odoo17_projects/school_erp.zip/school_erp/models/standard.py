from odoo import models, fields

class Standard(models.Model):
	_name = 'student.standard'

	standard = fields.Char(string="Name", required=True)
