from odoo import models , fields, api

class SchoolAttandance(models.Model):
	_name = 'school.attandance'
	_description = 'attandance'

	@api.depends('teacher_id', 'standard_id', 'timetable_id', 'from_time', 'to_time')
	def get_attendance_name(self):
		for obj in self:
			name = ""
			if obj.teacher_id:
				name = obj.teacher_id.name
			if obj.standard_id:
				if name:
					name = "%s - %s" % (name, obj.standard_id.standard)
				else:
					name = obj.standard_id.standard
			if obj.timetable_id:
				if name:
					name = "%s - %s" % (name, obj.timetable_id.name)
				else:
					name = obj.timetable_id.name
			if obj.from_time:
				if name:
					name = "%s - %s" % (name, obj.from_time)
				else:
					name =  "%s" % obj.from_time
			if obj.to_time:
				if name:
					name = "%s - %s" % (name, obj.to_time)
				else:
					name = "%s" % obj.to_time
			obj.name = name

	name = fields.Char("Name", compute="get_attendance_name", store=True)
	teacher_id = fields.Many2one('res.teacher',string="Teacher")
	standard_id = fields.Many2one('student.standard',string="Standard")
	timetable_id = fields.Many2one('school.timetable',string="TimeTable")
	from_time = fields.Float(string="From Time")  
	to_time = fields.Float(string="To Time")
	student_line_ids = fields.One2many('school.attendance.line', 'attendance_id', string="Students")
class SchoolAttendanceLine(models.Model):
	_name = 'school.attendance.line'
	_description = 'Attendance Line'

	attendance_id = fields.Many2one('school.attandance', string="Attendance")
	student_id = fields.Many2one('res.student', string="Student")
	present = fields.Boolean(string="Present", default=False)
